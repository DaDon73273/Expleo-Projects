package com.pageobjects;

import cucumber.api.java.eo.Se;
import net.serenitybdd.core.pages.PageObject;
import org.hamcrest.core.AnyOf;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class RegistrationPage extends PageObject {

    @FindBy(css = ".page-heading")
    private static WebElement checkPageHeading;
    @FindBy(css = "#uniform-id_gender1")
    private WebElement rbtMr;
    @FindBy(id = "#id_gender2")
    private WebElement rbtMrs;
    @FindBy(css = "#customer_firstname")
    private WebElement cust_fname;
    @FindBy(css = "#customer_lastname")
    private WebElement cust_lname;
    @FindBy(css = "#email")
    private static WebElement email;
    @FindBy(css = "#passwd")
    private WebElement password;
    @FindBy(css = "#days")
    private WebElement selDay;
    @FindBy(css = "#months")
    private WebElement selMonth;
    @FindBy(css = "#years")
    private WebElement selYear;
    @FindBy(id = "uniform-newsletter")
    private WebElement newsletterSignIn;
    @FindBy(id = "uniform-optin")
    private WebElement tailoredOffers;
    @FindBy(css = "#firstname")
    private WebElement addressFname;
    @FindBy(css = "#lastname")
    private WebElement addressLname;
    @FindBy(css = "#company")
    private WebElement company;
    @FindBy(css = "#address1")
    private WebElement address1;
    @FindBy(css = "#address2")
    private WebElement address2;
    @FindBy(css = "#city")
    private WebElement city;
    @FindBy(css = "#id_state")
    private WebElement selState;
    @FindBy(css = "#postcode")
    private WebElement zipCode;
    @FindBy(css = "#id_country")
    private WebElement selCountry;
    @FindBy(css = "#other")
    private WebElement otherInfo;
    @FindBy(css = "#phone")
    private WebElement hPhone;
    @FindBy(css = "#phone_mobile")
    private WebElement mPhone;
    @FindBy(css = "#alias")
    private WebElement futureRef;
    @FindBy(css = "#submitAccount")
    private WebElement regCustomer;

    public static String getRegistrationPage(String expected){
        String actual=checkPageHeading.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected+=" does not match page heading";
        }
        return expected;
    }

    public void setRbtOption(String gender){
           if(gender.equalsIgnoreCase("Male")){
               rbtMr.click();
           }else if(gender.equalsIgnoreCase("Female")){
               rbtMrs.click();
           }
    }



    public void setCust_fname(String firstname){
        cust_fname.clear();
        cust_fname.sendKeys(firstname);
    }

    public void setCust_lname(String lastname){
        cust_lname.clear();
        cust_lname.sendKeys(lastname);
    }

    public void setEmail(String _email){
        email.clear();
        email.sendKeys(_email);
    }

    public void setPassword(String _password){
        password.clear();
        password.sendKeys(_password);
    }

    public void setSelDay(int day){
        Select select=new Select(selDay);
        select.selectByIndex(day);
    }

    public void setSelMonth(String month){
        Select select=new Select(selMonth);
        select.selectByValue(month);
    }

    public void setSelYear(String year){
        Select select=new Select(selYear);
        select.selectByValue(year);
    }
    public void checkNewsletter(String response){
        if(response.equalsIgnoreCase("Yes")){
            newsletterSignIn.click();
        }
    }
    public void checkTailoredOffers(String response){
        if(response.equalsIgnoreCase("Yes")){
            tailoredOffers.click();
        }
    }
    public void setAddressFname(String firstname){
        addressFname.clear();
        addressFname.sendKeys(firstname);
    }

    public void setAddressLname(String lastname){
        addressLname.clear();
        addressLname.sendKeys(lastname);
    }

    public void setCompany(String companyName){
        company.clear();
        company.sendKeys(companyName);
    }

    public void setAddress1(String address){
        address1.clear();
        address1.sendKeys(address);
    }

    public void setAddress2(String address){
        address2.clear();
        address2.sendKeys(address);
    }

    public void setCity(String _city){
        city.clear();
        city.sendKeys(_city);
    }

    public void setSelState(int state){
        Select select=new Select(selState);
        select.selectByIndex(state);
    }

    public void setZipCode(String code){
        zipCode.clear();
        zipCode.sendKeys(code);
    }

    public void setSelCountry(int country){
        Select select=new Select(selCountry);
        select.selectByIndex(country);
    }

    public void setOtherInfo(String info){
        otherInfo.clear();
        otherInfo.sendKeys(info);
    }

    public void sethPhone(String phone)
    {
        hPhone.clear();
        hPhone.sendKeys(phone);
    }

    public void setmPhone(String phone){
        mPhone.clear();
        mPhone.sendKeys(phone);
    }

    public void setFutureRef(String ref){
        futureRef.clear();
        futureRef.sendKeys(ref);
    }

    public void clickBtnRegister(){
        regCustomer.click();
    }

}
