package com.pageobjects;


import net.serenitybdd.core.pages.PageObject;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class AddToCartPage extends PageObject {
    private Actions builder;
    @FindBy(xpath = "//*[@id=\"center_column\"]/h1/span[1]")
    private WebElement checkTshirt;
    @FindBy(xpath = "//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]/span")
    private WebElement btnaddTshirt;
    @FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[1]/h2")
    private WebElement addToCartSuccessful;
    @FindBy(className = "continue")
    private WebElement continueShopping;
    @FindBy(xpath = "//*[@id=\"center_column\"]/ul/li/div/div[2]/span/span")
    private WebElement inStock;
    @FindBy(xpath = "//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]/span")
    private WebElement hAddToCart;
    @FindBy(xpath = "//*[@id=\"homefeatured\"]/li[5]/div/div[2]/h5")
    private WebElement summerDress;
    @FindBy(xpath = "//*[@id=\"homefeatured\"]/li[5]/div/div[2]/div[2]/a[1]/span")
    private WebElement addSummerDress;
    @FindBy(xpath = "//a[@title='Proceed to checkout']")
    private WebElement btnCheckout;
    @FindBy(id = "cart_summary")
    private static WebElement tblCart;

    public String tShirtPage(String expected){
        String actual=checkTshirt.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected=" Incorrect Page Heading("+expected+") you might be in the wrong page";
        }catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

        return expected;
    }

    public String successfulAddToCart(String expected){
        new WebDriverWait(getDriver(),3).until(ExpectedConditions.visibilityOf(addToCartSuccessful));
        String actual=addToCartSuccessful.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected="Error, item could not be added to cart";
        }catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

        return expected;
    }

    public void addSummerDressToCart(){
        builder=new Actions(getDriver());
        builder.moveToElement(summerDress).build().perform();
        addSummerDress.click();
    }
    public void addShirtToCart(){
        JavascriptExecutor js=(JavascriptExecutor)getDriver();
        js.executeScript("scroll(0,400);");
        builder=new Actions(getDriver());
        builder.moveToElement(inStock).build().perform();
        new WebDriverWait(getDriver(),3).until(ExpectedConditions.elementToBeClickable(hAddToCart));
        hAddToCart.click();
    }

    public void clickContinueShopping(){
        new WebDriverWait(getDriver(),3).until(ExpectedConditions.elementToBeClickable(continueShopping));
        continueShopping.click();
    }

    public void clickProceedToCheckout(){
        new WebDriverWait(getDriver(),3).until(ExpectedConditions.elementToBeClickable(btnCheckout));
        btnCheckout.click();
    }

    public static boolean viewItemsInCart(){
        boolean canView;
        try{
            assertThat("true",tblCart.isDisplayed());
            canView=true;
        }catch (AssertionError e){
            canView=false;
        }
        return canView;
    }
}
