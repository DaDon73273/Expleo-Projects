package com.pageobjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class NavPage extends PageObject {

    @FindBy(xpath = "//img[@class='logo img-responsive']")
    private WebElement logo;
    @FindBy(linkText = "Sign in")
    private WebElement signIn;
    @FindBy(css = "a[title='View my shopping cart']")
    private WebElement viewCart;
    @FindBy(linkText = "WOMEN")
    private WebElement aWOMEN;
    @FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[1]/a")
    private WebElement aTshirt;

    public void clickSignIn(){
        signIn.click();
    }

    public void hoverWomen(){
        Actions builder=new Actions(getDriver());
        builder.moveToElement(aWOMEN).build().perform();
        aTshirt.click();
    }

    public void clickLogo(){
        logo.click();
    }
}
