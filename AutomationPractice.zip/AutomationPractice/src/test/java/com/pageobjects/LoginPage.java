package com.pageobjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class LoginPage extends PageObject {
    @FindBy(id = "email_create")
    private WebElement emailCreate;
    @FindBy(id = "email")
    private WebElement email;
    @FindBy(id = "passwd")
    private WebElement password;
    @FindBy(css = "button[id='SubmitCreate']")
    private WebElement btnCreate;
    @FindBy(css = "button[id='SubmitLogin']")
    private WebElement btnLogin;
    @FindBy(css = ".page-heading")
    private static WebElement loginAuth;
    @FindBy(css = "#create_account_error")
    private static WebElement errorMessage;
    @FindBy(xpath = "//*[@id=\"center_column\"]/div[1]/ol/li")
    private static WebElement authFailed;

    public void setEmailCreate(String createEmail){
       emailCreate.clear();
       emailCreate.sendKeys(createEmail);
    }

    public void setEmail(String _email){
        email.clear();
        email.sendKeys(_email);
    }

    public void setPassword(String _password){
        password.clear();
        password.sendKeys(_password);
    }

    public void clickBtnCreate(){
        btnCreate.click();
    }

    public void clickBtnLogin(){
        btnLogin.click();
    }

    public static String confirmFailedLogin(String expected){
        String actual=authFailed.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected="Incorrect Error Message ('"+expected+"') Returned";
        }

        return expected;
    }

    public static String confirmLoginPage(String expected){
        String actual=loginAuth.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
           expected="Incorrect Page Heading ('"+expected+"') Returned";
        }
        return expected;
    }


    public boolean checkErrorElement(){
        boolean isDisplayed=false;
        if(errorMessage.isDisplayed()==true){
            isDisplayed=true;
        }
        return isDisplayed;
    }

}
