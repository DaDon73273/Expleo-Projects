package com.Steps;

import com.pageobjects.LoginPage;
import com.pageobjects.NavPage;
import com.pageobjects.RegistrationPage;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.junit.Ignore;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class RegistrationSteps  {

    LoginPage loginPage;
    NavPage navPage;
    RegistrationPage registrationPage;
    String emailAddress;
    @Step("Email Address: {0}")
    public void registrationPage(String email){
                   navPage.clickSignIn();
    }

    @Step("Customer Details\nTitle: {18}\nFirstname: {0}\nLastname: {1}\nEmail: {2}\nDate of Birth: {4} {5} {6}\nContact: 0{16}")
    public void regDetails(String firstname,String lastname,String email,String pass,int day,
                           String month,String year,String company,String address, String address1,
                           String city,int state,String zipCode,int country,String addInfo,
                           String hPhone,String mPhone,String addFReference,String gender,String news,String offers)
    {
        try{

            loginPage.setEmailCreate(email);
            loginPage.clickBtnCreate();
            registrationPage.setRbtOption(gender);
            registrationPage.setCust_fname(firstname);
            registrationPage.setCust_lname(lastname);
            registrationPage.setPassword(pass);
            registrationPage.setSelDay(day);
            registrationPage.setSelMonth(month);
            registrationPage.setSelYear(year);
            registrationPage.checkNewsletter(news);
            registrationPage.checkTailoredOffers(offers);
            registrationPage.setAddressFname(firstname);
            registrationPage.setAddressLname(lastname);
            registrationPage.setCompany(company);
            registrationPage.setAddress1(address);
            registrationPage.setAddress2(address1);
            registrationPage.setCity(city);
            registrationPage.setSelState(state);
            registrationPage.setZipCode(zipCode);
            registrationPage.setSelCountry(country);
            registrationPage.setOtherInfo(addInfo);
            registrationPage.sethPhone(hPhone);
            registrationPage.setmPhone(mPhone);
            registrationPage.setFutureRef(addFReference);
            Thread.sleep(5000);
            registrationPage.clickBtnRegister();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Step
    public void message(String msg){}
}
