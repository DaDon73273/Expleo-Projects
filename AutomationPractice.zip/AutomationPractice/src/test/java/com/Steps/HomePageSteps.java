package com.Steps;

import com.pageobjects.HomePage;
import net.thucydides.core.annotations.Step;

public class HomePageSteps {
    HomePage homePage;

    @Step("Get Homepage url")
    public void setHomePage(){
        homePage.getUrl();
    }
}
