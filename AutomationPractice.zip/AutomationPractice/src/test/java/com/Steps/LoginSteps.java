package com.Steps;

import com.pageobjects.LoginPage;
import com.pageobjects.NavPage;
import net.thucydides.core.annotations.Step;
import org.junit.Ignore;

public class LoginSteps {

    LoginPage loginPage;
    NavPage navPage;


    @Step("User navigate to login")
    public void userNavigateToLoginPage(){
        navPage.clickSignIn();
    }

    @Step("User Login Credebtials\nEmail: {0}\nPassword: {1}")
    public void setLoginCredentials(String email,String password){
        loginPage.setEmail(email);
        loginPage.setPassword(password);
        loginPage.clickBtnLogin();
    }

    @Step("Status: {0}")
    public void setMessage(String message){}
}
