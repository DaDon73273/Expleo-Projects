package com.Steps;

import com.pageobjects.AddToCartPage;
import com.pageobjects.NavPage;
import net.thucydides.core.annotations.Step;


public class AddToCartSteps {

    NavPage navPage;
    AddToCartPage addToCartPage;

    @Step
    public void navigateToItem(){
        navPage.hoverWomen();
    }
    @Step
    public void addItemToCart(String popUp){
        //addToCartPage.tShirtPage(header);
        addToCartPage.addShirtToCart();
        addToCartPage.successfulAddToCart(popUp);
        addToCartPage.clickContinueShopping();
        navPage.clickLogo();
        addToCartPage.addSummerDressToCart();
        addToCartPage.clickProceedToCheckout();
    }

    @Step("Example Status\n1. True: Item is displayed in cart\n2. False: Cart is Empty\nActual Status: {0}")
    public void statusMessage(boolean message){}
}
