package com.StepDefinition;

import com.Steps.AddToCartSteps;
import com.Steps.HomePageSteps;
import com.Steps.LoginSteps;
import com.Steps.RegistrationSteps;
import com.pageobjects.AddToCartPage;
import com.pageobjects.LoginPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.thucydides.core.annotations.Steps;

import java.io.FileInputStream;
import java.io.IOException;

public class MyStepDefs {
    @Steps
    HomePageSteps homePageSteps;
    @Steps
    RegistrationSteps registrationSteps;
    @Steps
    AddToCartSteps addToCartSteps;
    @Steps
    LoginSteps loginSteps;

    @Given("^User is in the Automation Practice Homepage$")
    public void user_is_in_the_Automation_Practice_Homepage() {
        // Open Browser or Home page
        homePageSteps.setHomePage();
    }

    @Given("^User navigate to registration Page$")
    public void user_navigate_to_registration_Page() {
        // Write code here that turns the phrase above into concrete actions
        String email="dddd@gmail.com";
        registrationSteps.registrationPage(email);
    }

    @When("^User register with the valid details$")
    public void user_register_with_the_valid_details() {
        // Write code here that turns the phrase above into concrete actions
        String fname,lname,email,password,month,year,firstname,lastname,company,address1,address2,city,zipcode,otherInfo,
                hPhone,mPhone,reference,gender,news,offer;
        int state,country,day;
        try{
            FileInputStream fi=new FileInputStream("Registration Details.xls");
            Workbook w=Workbook.getWorkbook(fi);
            Sheet s=w.getSheet("Customer");

            int count=1;
            for (int i = 1; i <=s.getRows() ; i++) {
                if(count>1){
                    fname=s.getCell("A"+i).getContents();
                    lname=s.getCell("B"+i).getContents();
                    email=s.getCell("C"+i).getContents();
                    password=s.getCell("D"+i).getContents();
                    day=Integer.valueOf(s.getCell("E"+i).getContents());
                    month=s.getCell("F"+i).getContents();
                    year=s.getCell("G"+i).getContents();
                    company=s.getCell("H"+i).getContents();
                    address1=s.getCell("I"+i).getContents();
                    address2=s.getCell("J"+i).getContents();
                    city=s.getCell("K"+i).getContents();
                    state=Integer.valueOf(s.getCell("L"+i).getContents());
                    zipcode=s.getCell("M"+i).getContents();
                    country=Integer.valueOf(s.getCell("N"+i).getContents());
                    otherInfo=s.getCell("O"+i).getContents();
                    hPhone=s.getCell("P"+i).getContents();
                    mPhone=s.getCell("Q"+i).getContents();
                    reference=s.getCell("R"+i).getContents();
                    gender=s.getCell("S"+i).getContents();
                    news=s.getCell("T"+i).getContents();
                    offer=s.getCell("U"+i).getContents();
                    registrationSteps.regDetails(fname,lname,email,password,day,month,year,
                            company,address1,address2,city,state,zipcode,country,otherInfo,
                            hPhone,mPhone,reference,gender,news,offer);

                }
                count++;
            }

        }catch (IOException e){
            System.out.println("Excel Error "+e.getMessage());
        } catch (BiffException e) {
            e.printStackTrace();
        }
    }

    @Then("^User should be successfully registered$")
    public void user_should_be_successfully_registered() {
        // Validate if user successfully registered
        registrationSteps.message(LoginPage.confirmLoginPage("MY ACCOUNT"));
    }

    @Given("^User navigate to login Page$")
    public void user_navigate_to_login_Page() {
        // Navigate to login page
        loginSteps.userNavigateToLoginPage();
    }

    @When("^User provide valid \"([^\"]*)\" and \"([^\"]*)\" as credentials$")
    public void user_provide_valid_and_as_credentials(String email, String password) {
        // Provide valid Login credentials
       loginSteps.setLoginCredentials(email,password);
    }


    @Then("^User should see the login \"([^\"]*)\"$")
    public void user_should_see_the_login(String message) {
        // Validate if user is in the right page
        loginSteps.setMessage(LoginPage.confirmLoginPage(message));

    }
    @Given("^User navigate to login page$")
    public void user_navigate_to_login_page() {
        // Navigate to login page
        loginSteps.userNavigateToLoginPage();
    }

    @When("^User provide invalid \"([^\"]*)\" and \"([^\"]*)\" as credentials$")
    public void user_provide_invalid_and_as_credentials(String email, String password) {
        // Try to login with invalid credentials
       loginSteps.setLoginCredentials(email,password);
    }

    @Then("^User should see the error \"([^\"]*)\"$")
    public void user_should_see_the_error(String message) {
        // Write code here that turns the phrase above into concrete actions
        loginSteps.setMessage(LoginPage.confirmFailedLogin(message));
    }

    @Given("^User navigate to items$")
    public void user_navigate_to_items(){
        // Write code here that turns the phrase above into concrete actions
        addToCartSteps.navigateToItem();

    }

    @When("^User click add to cart$")
    public void user_click_add_to_cart() {
        // Write code here that turns the phrase above into concrete actions
        String tShirtPageHearder;
        String addToCartSuccessfull="Product successfully added to your shopping cart";
        addToCartSteps.addItemToCart(addToCartSuccessfull);
    }

    @Then("^User should see the Item in the cart$")
    public void user_should_see_the_Item_in_the_cart() {
        // Display the status for cart
        addToCartSteps.statusMessage(AddToCartPage.viewItemsInCart());
    }

}
