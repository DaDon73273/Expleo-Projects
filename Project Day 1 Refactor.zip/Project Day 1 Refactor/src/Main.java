import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    private static Connection conn= CreateConnection.getConnection();
    private static ResultSet rs=null;
    private static File file2;


    //Check if File Exist
    public static boolean fileExist(String fileName) {
        file2 = new File(fileName);
        boolean isExist = false;

        if (file2.exists()==true) {
            isExist=true;
        }
        return isExist;
    }


    //Check if the file is empty
    public static boolean fileHaveData(String fname) {

        file2=new File(fname);
        boolean isEmpty=true;
        if(file2.length()<4){
            isEmpty=false;
        }
        return isEmpty;
    }

    //Check if Database exist
    public static boolean dbExist(String fname){
        File file=new File(fname);
        String[] data;
        boolean isExist=false;

        Scanner rFile= null;
        try {
            //Read file
            rFile = new Scanner(new FileReader(file));
            //Skip the first line
            rFile.nextLine();
            //Read from the second line
            while (rFile.hasNextLine()){
                String readNextLine=rFile.nextLine();
                data=readNextLine.split(",");
                //Creating a file with a database name
                File dFile=new File(data[0]+".db");
                if(dFile.exists()==true) {
                    isExist=true;
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
       return isExist;

    }
    //Checking if the table exist
    public static String tableExist(String tableName) throws SQLException {
        String sql="SELECT name FROM sqlite_master WHERE type='table' AND name='"+tableName+"'";
        PreparedStatement prst;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
        } catch (SQLException e) {
            System.out.println("Sql Error, "+e.getMessage());
        }
        return rs.getString("name");
    }

    //Check if Key column exist
    public static boolean keyColumnExist(String name,String tableName){
        boolean isExist=false;
        String sql="select count("+name+") 'column' FROM '"+tableName+"'";
        PreparedStatement prst=null;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("column"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            System.out.println(name+" does not exist");
        }
        return isExist;
    }

    //Check if the column Exist
    public static boolean columnExist(String name,String tableName){
        boolean isExist=false;
        String sql="select count("+name+") 'column' FROM '"+tableName+"'";
        PreparedStatement prst=null;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("column"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            System.out.println(name+" does not exist");
        }
        return isExist;
    }

    //Check if key column value match
    public static String getKeyColumnValue(String tableName,String keyColumnValue,String keyColumn){
        String sql="select "+keyColumnValue+" 'Value' from "+tableName+" where "+keyColumn+" = '"+keyColumnValue+"'";
        PreparedStatement prst=null;
        String value="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            value=rs.getString("Value");
        } catch (SQLException e) {
            System.out.println(keyColumnValue+ " Does not match");
        }
        return value;
    }
    //Check if column value match
    public static String columnValueMatch(String columnName,String tableName,String columnValue){
        String sql="select "+columnName+" 'value' from "+tableName+" where "+columnName+" = '"+columnValue+"'";
        PreparedStatement prst;
        String value="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            value=rs.getString("value");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return value;
    }
}
