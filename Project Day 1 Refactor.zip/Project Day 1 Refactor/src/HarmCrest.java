import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class HarmCrest {
    private   String fname="DataFile.txt";
    private static Connection conn= CreateConnection.getConnection();
    private static ResultSet rs=null;
    protected static File file2;
    private static String dataLine = "";
    private Scanner rFile;
    @Test
    public void checkFileExist(){


            assertThat(fname+" does not exist",true,is(Main.fileExist(fname)));
    }

    @Test
    public void checkFileData(){
        assertThat(fname+" is empty",true,is(Main.fileHaveData(fname)));
    }

    @Test
    public void checkDatabaseExist(){
        assertThat("Does not exist",true,is(Main.dbExist(fname)));
    }

    @Test
    public void tableExist(){
        //Initialize tableName with the name of the table that you want to test with
        String tableName="";
        try {
            assertThat(tableName+" does not exist","artists",equalTo(Main.tableExist(tableName)));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void checkKeyColumn(){
        String keyColumn="";
        String tableName="";
        assertThat(keyColumn+" Does not match",true,is(Main.keyColumnExist(keyColumn,tableName)));
    }

    @Test
    public void checkKeyColumnValue(){
        String tableName="";
        String keyValue="";
        String keyColumn="";

        try{
            assertThat(keyValue+" does not match",true,is(Main.getKeyColumnValue(tableName,keyValue,keyColumn)));
        }catch (AssertionError e){

        }
    }

    @Test
    public void MainTest(){
        readFile();
    }

    public void readFile(){


        String[] data;
        file2=new File(fname);




        //Read file
        try {
            rFile=new Scanner(new FileReader(file2));

            //Skip the first line
            rFile.nextLine();

            //Read from the second line
            while (rFile.hasNextLine()) {
                try {

                    String readNextLine = rFile.nextLine();
                    data = readNextLine.split(",");

                    //Creating a file with a database name
                    File dFile = new File(data[0] + ".db");
                    if (dFile.exists() == true) {
                        if (tableExist(data[1]).equalsIgnoreCase(data[1])) {
                            if (Main.keyColumnExist(data[2], data[1]) == true) {
                                if (Main.getKeyColumnValue(data[1], data[3], data[2]).equalsIgnoreCase(data[3])) {
                                    if (Main.columnExist(data[4], data[1]) == true) {
                                        if (Main.columnValueMatch(data[4], data[1], data[5]).equalsIgnoreCase(data[5])) {
                                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5] +" OK\n";
                                            // continue;
                                        }else {
                                            try {
                                                assertThat(data[5]+" does not match",data[5] , CoreMatchers.is(equalTo(Main.columnValueMatch(data[4], data[1], data[5]))));

                                            } catch (AssertionError e) {
                                                dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not match\n";
                                                //dataLine += data[5]+" does not match" + "\n";
                                                continue;
                                            }
                                        }
                                    }else{
                                        try {
                                            assertThat(data[4]+" does not exist",true , CoreMatchers.is(Main.columnExist(data[4], data[1])));

                                        } catch (AssertionError e) {
                                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not exist" + "\n";
                                            continue;
                                        }
                                    }
                                }else{
                                    try {
                                        assertThat(data[3]+" does not match",data[3] ,equalTo(Main.getKeyColumnValue(data[1], data[3], data[2])));
                                    } catch (AssertionError e) {
                                        dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not match" + "\n";
                                        continue;
                                    }
                                }
                            }else{
                                try {
                                    assertThat(data[2]+" does not exist", true, CoreMatchers.is(Main.columnExist(data[4],data[1])));
                                } catch (AssertionError e) {
                                    dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not exist" + "\n";
                                    continue;
                                }
                            }
                        } else {
                            try {
                                assertThat("Invalid Table", data[1], CoreMatchers.is(equalTo(tableExist(data[1]))));
                            } catch (AssertionError e) {
                                dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+ " Invalid Table" + "\n";
                                // System.out.println(e.getMessage());
                                continue;
                            }
                        }

                    } else {
                        try {
                            assertThat("Invalid Database", true, CoreMatchers.is(dFile.exists()));
                        } catch (AssertionError e) {
                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+ " Invalid Database" + "\n";
                            continue;
                        }
                    }


                } catch (ArrayIndexOutOfBoundsException ex) {
                    if (ex.getMessage().equals("0")) {
                        System.out.println("Error: Database can not be empty at index " + ex.getMessage());
                    } else if (ex.getMessage().equals("1")) {
                        System.out.println("Error: Table can not be empty at index " + ex.getMessage());
                    } else if (ex.getMessage().equals("2")) {
                        System.out.println("Error: Key Column can not be empty at index " + ex.getMessage());
                    } else if (ex.getMessage().equals("3")) {
                        System.out.println("Error: Key Value can not be empty at index " + ex.getMessage());
                    } else if (ex.getMessage().equals("4")) {
                        System.out.println("Error: Column can not be empty at index " + ex.getMessage());
                    } else if (ex.getMessage().equals("5")) {
                        System.out.println("Error: Column Value can not be empty at index " + ex.getMessage());
                    }
                    continue;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }


    //Checking if the table exist
    public static String tableExist(String tableName) {
        String sql="SELECT name FROM sqlite_master WHERE type='table' AND name='"+tableName+"'";
        PreparedStatement prst;
        String name="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            name=rs.getString("name");
        } catch (SQLException e) {
            System.out.println("Sql Error, "+e.getMessage());
        }
        return name;
    }
}
