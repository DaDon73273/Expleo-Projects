import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConnection {

    private static Connection conn;
    public static Connection getConnection(){
        String url="jdbc:sqlite:chinook.db";
        String username="",password="";
        try {
            conn= DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            System.out.println("Error, "+e.getMessage());
            //e.printStackTrace();
        }
        return conn;
    }
}
