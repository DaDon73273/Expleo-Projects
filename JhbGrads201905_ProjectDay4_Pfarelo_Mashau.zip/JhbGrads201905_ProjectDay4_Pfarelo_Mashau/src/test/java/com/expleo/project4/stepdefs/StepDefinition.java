package com.expleo.project4.stepdefs;

import com.expleo.project4.steps.DataTransferSteps;
import cucumber.api.java.en.*;
import net.thucydides.core.annotations.Steps;


public class StepDefinition {
    String databaseName = "chinook.db";
    String blogName = "db.json";
    String url = "http://localhost:3000";
    String artistName = "Caetano Veloso";
    int statusCode=201;
    @Steps
    DataTransferSteps dataTransferSteps;

    @Given("^I have chinook and Blog database$")
    public void i_have_chinook_and_Blog_database() {
        dataTransferSteps.getMessage(dataTransferSteps.checkDatabaseExist(databaseName,blogName,url,artistName));
    }


    @When("^I transfer the album info for an artist$")
    public void i_transfer_the_album_info_for_an_artist() {
        dataTransferSteps.dataTransfer(dataTransferSteps.transferDataToBlog(artistName));
    }

    @When("^Delete data from chinook$")
    public void delete_data_from_chinook() {
        dataTransferSteps.deleteAlbums(dataTransferSteps.deleteTransferedDataAlbumFromChinookDb(artistName));
        dataTransferSteps.deleteTransferredArtist(dataTransferSteps.deleteTransferredArtistFromChinook(artistName));
    }

    @Then("^Album info should be successfully transferred$")
    public void album_info_should_be_successfully_transferred() {
        dataTransferSteps.verifyStatusCode(dataTransferSteps.verifyStatusCode(statusCode));
    }

   /* @Then("^Transferred data should be deleted from chinook$")
    public void transferred_data_should_be_deleted_from_chinook() {
        // Write code here that turns the phrase above into concrete actions

    }*/
}
