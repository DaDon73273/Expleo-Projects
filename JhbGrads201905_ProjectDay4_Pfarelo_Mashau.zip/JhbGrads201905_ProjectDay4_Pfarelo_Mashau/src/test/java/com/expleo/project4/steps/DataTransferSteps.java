package com.expleo.project4.steps;

import com.expleo.project4.DBConnection.DatabaseConnection;
import com.expleo.project4.Model.Blog;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class DataTransferSteps {

    //Assertions
    public String checkDatabaseExist(String database, String blogName, String url, String artistName) {
        String message = "";
        int arSize = 0;
        try {
            assertThat(true, is(equalTo(DatabaseConnection.checkDbExist(database)))); //Check if Database Exist
            message += "\n" + database + " found!\n";
            DatabaseConnection.getConnection(); //Create connection to chinook Database
            assertThat(true, is(equalTo(DatabaseConnection.checkArtistTableExist()))); //Check if Artist Table EXist
            message += "Table Artist Exist\n";
            assertThat(true, is(equalTo(DatabaseConnection.checkIfTableArtistIsReadable()))); //Check if Artist Table is Readable
            message += "Artist table is Readable\n";
            assertThat(true, is(equalTo(DatabaseConnection.checkAlbumTableExist()))); //Check if Albums Table EXist
            message += "Album Table Exist\n";
            assertThat(true, is(equalTo(DatabaseConnection.checkIfTableAlbumIsReadable())));//Check if Albums Table is Readable
            message += "Album Table is readable\n";
            arSize = DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).size();
            assertThat(arSize, greaterThan(0));// Check if Artist have Albums
            message += artistName + " have " + arSize + " albums in the database\n";
            assertThat(true, is(equalTo(Blog.checkBlogDbExist(blogName)))); //Check if db.Json Exist
            message += blogName + " Database Exist\n";
            Blog.setupRestFulService(url); //Setting Up RestFul Service
            message += "Connected to: " + url + " Database\n";
        } catch (AssertionError e) {
            if (DatabaseConnection.checkDbExist(database) == false) {
                message += "\"" + database + "\" does not exist";
            } else if (DatabaseConnection.checkArtistTableExist() == false) {
                message += "Table Artist does not Exist";
            } else if (DatabaseConnection.checkIfTableArtistIsReadable() == false) {
                message += "Artist table is not Readable";
            } else if (DatabaseConnection.checkAlbumTableExist() == false) {
                message += "Album Table does not Exist";
            } else if (DatabaseConnection.checkIfTableAlbumIsReadable() == false) {
                message += "Album Table is not readable";
            } else if (Blog.checkBlogDbExist(blogName) == false) {
                message += "\"" + blogName + "\" Database does not Exist";
            } else if (arSize < 1) {
                message += "\"" + artistName + "\" does not albums in the database";
            }

        }
        return message;
    }

    //Transfer data from chinook to db.Json database
    public String transferDataToBlog(String artistName) {
        String message = "";

        try {
            assertThat(DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).size(),is(greaterThan(0)));//Check if the array has data
            for (int i = 0; i < DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).size(); i++) {
                Blog.submitNewComment(artistName + " " + DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).get(i).getTitle());
                message += "\nYou have successfully added a Comment: " + artistName + " - " +
                        DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).get(i).getTitle() + " to the database";

            }
        } catch (AssertionError e) {
            message += "Failed to add Comment to the database";
        } catch (NullPointerException e) {
            message += "Failed to add Comment to the database";
        }
        return message;
    }

    //Delete Artist Albums from Chinook database
    public String deleteTransferedDataAlbumFromChinookDb(String artistName) {
        String message = "";
        try {
            assertThat(DatabaseConnection.checkIfAlbumsFoundForArtist(artistName).size(), is(greaterThan(0)));//Check if Array contain data
            assertThat(true, is(equalTo(DatabaseConnection.deleteAlbumsFromChinookDb(artistName))));
            message = "Successfully deleted \"" + artistName + "\" Albums";

        } catch (AssertionError e) {
            message += " Failed to delete \"" + artistName + "\" Albums or no data matches \"" + artistName + "\" Found";
        } catch (NullPointerException e) {
            message += " Failed to delete \"" + artistName + "\" Albums or no data matches \"" + artistName + "\" Found";
        }
        return message;
    }

    //Delete artist data from chinook database
    public String deleteTransferredArtistFromChinook(String artistName) {
        String message = "";
        try {
            assertThat(true, is(equalTo(DatabaseConnection.deleteTransferredArtistData(artistName))));//Check if Data deleted
            message += " \"" + artistName + "\" deleted successfully";
        } catch (AssertionError e) {
            message += " Failed to Delete \"" + artistName + "\" or no data matches \"" + artistName + "\" Found";
        } catch (NullPointerException e) {
            message += " Failed to Delete \"" + artistName + "\" or no data matches " + artistName + " Found";
        }
        return message;
    }

    //Verify the status code for posting
    public String verifyStatusCode(int code){
        String message="";
        try{
            assertThat(Blog.getReturnCode(code),is(equalTo(code)));//Check if the status code is equal to 201
            message="\""+code+"\""+ " matched the actual status code";
        }catch (AssertionError error){
            message="\""+code+"\""+ " did not match the actual status code";

        }catch (NullPointerException e){
            message="\""+code+"\""+ " did not match the actual status code";
        }
        return message;
    }

    @Step("Database Status: {0}")
    public void getMessage(String message) {
    }

    @Step("Status: {0}")
    public void dataTransfer(String message) {
    }

    @Step("Delete Status: {0}")
    public void deleteAlbums(String message) {
    }

    @Step("Delete Status: {0}")
    public void deleteTransferredArtist(String message) {
    }
    @Step("Status message: {0}")
    public void verifyStatusCode(String message){}

}
