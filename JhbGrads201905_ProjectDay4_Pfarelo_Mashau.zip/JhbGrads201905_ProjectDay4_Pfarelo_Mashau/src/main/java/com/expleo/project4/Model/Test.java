package com.expleo.project4.Model;

public class Test {

    public static void main(String[] args) {
       /* System.out.println(Artists.checkDbExist("chinook.db"));

        System.out.println(DatabaseConnection.getConnection());

        System.out.println(Artists.checkIfTableExists("artist"));

        System.out.println(Artists.checkAlbumExist("Big Ones"));
*/

        //System.out.println(Artists.checkIfAlbumsHaveData("Caetano Veloso").get(1).substring(0,Artists.checkIfAlbumsHaveData("Caetano Veloso").get(1).indexOf(" ")).trim());

        //System.out.println(Artists.checkIfAlbumsHaveData("Caetano Veloso"));
    }
}
