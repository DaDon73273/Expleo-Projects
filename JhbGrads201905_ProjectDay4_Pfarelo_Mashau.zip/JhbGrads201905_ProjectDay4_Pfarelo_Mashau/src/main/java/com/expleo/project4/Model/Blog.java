package com.expleo.project4.Model;

import java.io.File;
import com.google.gson.JsonObject;
import io.restassured.specification.RequestSpecification;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class Blog {
    static File fileName;
    private static JsonObject jsonObject;
    private static RequestSpecification request;
    private static String url;
    private static Response response;

    //Check if Blog Db exist
    public static boolean checkBlogDbExist(String dbName){
        fileName=new File(dbName);
        boolean isExists=false;
        if(fileName.exists()){
            isExists=true;
        }
        return isExists;
    }

    //Create connection to Blog Database
    public static void setupRestFulService(String _url) {
        jsonObject = new JsonObject();
        request = given().contentType("application/json");
        url = _url;

    }

    //Create the post Method for Blog Database
    public static void submitNewComment(String comment)
    {
        jsonObject.addProperty("body",comment);
       // jsonObject.addProperty("postId","1");
        request = request.body(jsonObject).when();
        // request.post(url + "/comments");
        response = request.post(url + "/comments");
    }

    //Return the status code
    public static int getReturnCode(int returnCode)
    {
        int statusCode=0;
        try{
            request.then().statusCode(returnCode);
             statusCode= response.statusCode();

        }catch (NullPointerException e){
            statusCode=404;
        }

        //System.out.println("verifyReturnCode  Status Code  : " + response.getStatusCode());
        //assertThat(returnCode, equalTo(response.getStatusCode())); //WS
        return statusCode;
    }

}
