package com.expleo.project4.DBConnection;

import com.expleo.project4.Model.Albums;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;

public class DatabaseConnection {

    private static Connection conn=null;
    public static Connection getConnection(){

        String url="jdbc:sqlite:chinook.db";
        String username="",password="";
        try {
            conn= DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            System.out.println("Error, "+e.getMessage());
        }
        return conn;
    }

    //Check if Chinook Database Exist
    public static boolean checkDbExist(String dbName){
         File fileName;
         ResultSet rs;
        fileName=new File(dbName);
        boolean isExists=false;

        if(fileName.exists()){
            isExists=true;
        }
        return isExists;
    }

    //Check if Table Artist Exist
    public static boolean checkIfTableArtistIsReadable()
    {
        String sql = "Select * from artists";
        boolean found = false;
        Statement stmnt;

        try
        {
            stmnt = conn.createStatement();
            found = stmnt.execute(sql);
        }
        catch (SQLException e)
        {
            found =false;
        }
        return found;
    }


    //Check if albums table is readable
    public static boolean checkIfTableAlbumIsReadable()
    {
        String sql = "Select * from albums";
        boolean found = false;
        Statement stmnt;

        try
        {
            stmnt = conn.createStatement();
            found = stmnt.execute(sql);
        }
        catch (SQLException e)
        {
            found =false;
        }
        return found;
    }
    //Check if Album Table exist
    public static boolean checkAlbumTableExist(){
        ResultSet rs;
        boolean isExist=false;
        String sql="select count(*) as count from albums";
        PreparedStatement prst;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("count"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            isExist=false;
        }
        return isExist;
    }

    public static boolean checkArtistTableExist(){
        ResultSet rs;
        boolean isExist=false;
        String sql="select count(*) as count from artists";
        PreparedStatement prst;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("count"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            isExist=false;
        }
        return isExist;
    }


    //Check if albums found for artist
    public static ArrayList<Albums> checkIfAlbumsFoundForArtist(String artistName){
        ResultSet rs;
        String sql="select albums.albumId,title,albums.artistId  from albums" +
                " left join artists on albums.artistid=artists.artistid " +
                "where name=?";

        ArrayList<Albums> arAlbum=new ArrayList<>();
        PreparedStatement prst;
        Albums objAlbums;
        try {
            prst=conn.prepareStatement(sql);
            prst.setString(1,artistName);
            rs=prst.executeQuery();
            while (rs.next())
            {
                objAlbums=new Albums(rs.getInt(1),rs.getString(2),rs.getInt(3));
                arAlbum.add(objAlbums);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return arAlbum;
    }

    //Get ArtistId
    public static int getArtistName(String artistName){
        String sql="SELECT artistId as id FROM Artists WHERE name=?";
        ResultSet rs=null;
        PreparedStatement prst=null;
        int artistId=0;
        try {
            prst=conn.prepareStatement(sql);
            prst.setString(1,artistName);
            rs=prst.executeQuery();
            artistId=rs.getInt("id");
        } catch (SQLException e) {
           artistName+=" is not found";
        }
        return artistId;
    }

    //Getting the Size of Albums Array
    public static int getAlbums(int artistId){
        String sql="select * from albums where artistId=?";
        ResultSet rs;
        PreparedStatement prst=null;
        ArrayList<Albums> arAlbums=new ArrayList<>();
        try {
            prst=conn.prepareStatement(sql);
            prst.setInt(1,artistId);
            rs=prst.executeQuery();
            while (rs.next()){
                arAlbums.add(new Albums(rs.getInt(1),rs.getString(2),rs.getInt(3)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arAlbums.size();
    }

   //Delete from Albums from chinook database using ArtistName
    public static boolean deleteAlbumsFromChinookDb(String artistName){
        int artistId=getArtistName(artistName);
        String sql="DELETE FROM Albums WHERE artistId=?";
        PreparedStatement prst;
        boolean isDeleted=false;
        try {
            prst=conn.prepareStatement(sql);
            prst.setInt(1,artistId);
            System.out.println("Array: "+getAlbums(2));
                if(getAlbums(artistId)!=0){
                    isDeleted=prst.execute();
                    isDeleted=true;
                }
        } catch (SQLException e) {
            isDeleted=false;
        }
        return isDeleted;
    }

    //Delete Artist data using artist Name
    public static boolean deleteTransferredArtistData(String artistName){
        String sql="DELETE FROM artists WHERE name=?";
        String sql1="SELECT count(*) as count FROM artists WHERE name=?";
        ResultSet rs;
        boolean isDeleted=false;
        PreparedStatement prst;
        PreparedStatement prst1;

        try {
            prst1=conn.prepareStatement(sql1);
            prst1.setString(1,artistName);
            rs=prst1.executeQuery();
            if(Integer.valueOf(rs.getString("count"))>0){
                prst=conn.prepareStatement(sql);
                prst.setString(1,artistName);
                isDeleted=prst.execute();
                isDeleted=true;
            }

        } catch (SQLException e) {
            isDeleted= false;
        }
        return isDeleted;
    }
}
