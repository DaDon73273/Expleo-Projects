package com.expleo.project4.Model;


public class Artists {


    int artistID;
    String artistName;

    public Artists(int artistID, String artistName)
    {
        setArtistID(artistID);
        setArtistName(artistName);
    }

    public int getArtistID() {
        return artistID;
    }

    public void setArtistID(int artistID) {
        this.artistID = artistID;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

}
