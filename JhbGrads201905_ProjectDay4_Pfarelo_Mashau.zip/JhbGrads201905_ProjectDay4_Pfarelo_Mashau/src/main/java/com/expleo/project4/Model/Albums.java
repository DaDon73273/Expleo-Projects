package com.expleo.project4.Model;

public class Albums
{
    int albumId;
    String title;
    int artistId;

    public Albums(int albumId, String title, int artistId) {
        setAlbumId(albumId);
        setTitle(title);
        setArtistId(artistId);

    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
