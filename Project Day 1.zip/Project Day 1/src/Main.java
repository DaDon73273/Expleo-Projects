import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) {
        //getData();
        readFromFile();
    }

    public static void readFromFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter File Name: ");
        String fName = scanner.nextLine();
        File file = new File(fName);
        String[] data;


        if (file.exists()) {
            try {
                Scanner scanner1 = new Scanner(new FileReader(file));
                scanner1.nextLine();
                while (scanner1.hasNextLine()) {
                    String getName = scanner1.nextLine();
                    data = getName.split(",");
                    if (file.length() != 0) {
                        File database = new File(data[0] + ".db");
                        if (database.exists()) {
                            getData(data[3], data[5], data[1], data[2], data[4]);
                        } else {
                            System.out.println(database + " Not Found");
                        }
                    } else {
                        System.out.println(file + " is empty");
                    }
                }

            } catch (IOException ex) {

            } catch (ArrayIndexOutOfBoundsException ex) {
                System.out.println("Array Error " + ex.getMessage());
            }
        } else {

        }

    }


    public static void getData(String id, String name, String tableName, String keyColumn, String column) {
        String selectQuery = "select * from " + tableName + " where " + keyColumn + "=? and " + column + "=?";
        Connection conn = CreateConnection.connect();
        ResultSet rs = null;
        PreparedStatement prst = null;
        PreparedStatement prst1 = null;
        ResultSet rs1 = null;

        try {

            prst = conn.prepareStatement(selectQuery);
            prst.setString(1, id);
            prst.setString(2, name);
            rs = prst.executeQuery();


            while (rs.next()) {
                //System.out.println(rs.getString(keyColumn)+" "+rs.getString(column));
                System.out.println("OK");
            }




        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
    }
}

