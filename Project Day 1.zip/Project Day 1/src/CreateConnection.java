import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConnection {

    private static Connection conn;
    public static Connection connect()  {
       try{
           String url="jdbc:sqlite:chinook.db";
           String user="",pass="";
           conn= DriverManager.getConnection(url,user,pass);
       }catch (SQLException ex){
           System.out.println("Error "+ ex.getMessage());
       }
        return  conn;
    }
}
