import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.sql.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

public class HarmCrest {
    @Before
    public void setup(){
        CreateConnection.connect();
    }

    @Test
    public void test1() {
        String selectQuery = "select * from artists where artistid=? and name=?";
        Connection conn = CreateConnection.connect();
        PreparedStatement prst = null;
        ResultSet rs = null;

        try {

            prst = conn.prepareStatement(selectQuery);
            prst.setString(1, "2");
            prst.setString(2, "accept");


            rs = prst.executeQuery();
            String artist = rs.getString("ArtistId");
            String name = rs.getString("Name");
            while (rs.next()) {
                System.out.printf("%-12s%-12s", artist, name);
                assertThat("Name not Found", "Accept", equalTo(name));

            }

            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
        }
        }

    }
