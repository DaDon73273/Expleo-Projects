package serenity;

import com.project2.DataMethods;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class SerenityClass {
    String fName="data.txt";
    DataMethods dataMethods = new DataMethods();
    String dLine="";
    @Step
    public void csvExist() {
        dataMethods.getFile();
    }

    @Step
    public void csvProcessing(){
        dataMethods.readFile();
    }

    @Step("{0}")
    public void csvResults(String message){

    }
}
