package steps;

import com.project2.DataMethods;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import serenity.SerenityClass;

public class Stepdeff {

    @Steps
    SerenityClass serenityClass;
    @Given("^I have input CSV file$")
    public void i_have_input_CSV_file() {
        serenityClass.csvExist();
    }

    @When("^I process the file$")
    public void i_process_the_file() {
        serenityClass.csvProcessing();
    }

    @Then("^I should see the message$")
    public void i_should_see_the_message() {
        serenityClass.csvResults(DataMethods.getDataLine());
    }

}
