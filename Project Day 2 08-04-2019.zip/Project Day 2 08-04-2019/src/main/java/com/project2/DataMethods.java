package com.project2;

import com.dbconnection.CreateConnection;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class DataMethods {
    private static Connection conn= CreateConnection.getConnection();
    private static ResultSet rs=null;
    protected static File file2;
    private static String dataLine = "";
    private Scanner rFile;



    public DataMethods() {
    }



    public static boolean fileExist(String fileName) {
        file2 = new File(fileName);
        boolean isExist = false;

        if (file2.exists()==true) {
            isExist=true;
        }
        return isExist;
    }

    public  void getFile(){
        String fname="Datafile.txt";
        if(fileExist(fname)==true){
            if(fileHaveData(fname)){

            }else {
                try {
                    assertThat(fname+" does not exist", true, is(fileExist(fname)));
                } catch (AssertionError e) {
                    dataLine += fname+" is Empty" + "\n";
                    // continue;
                }
            }
        }else {
            try {
                assertThat(fname+" does not exist", true, is(fileExist(fname)));
            } catch (AssertionError e) {
                dataLine += fname+" does not exist" + "\n";
               // continue;
            }
        }
    }

    public static boolean fileHaveData(String fname) {

        file2=new File(fname);
        boolean isEmpty=true;
        if(file2.length()==0){
            isEmpty=false;
        }
        return isEmpty;
    }

    public static String getDataLine(){
        return dataLine;
    }
    public void readFile(){


        String[] data;





        //Read file
        try {
            rFile=new Scanner(new FileReader(file2));

        //Skip the first line
            rFile.nextLine();

            //Read from the second line
            while (rFile.hasNextLine()) {
                try {

                String readNextLine = rFile.nextLine();
                data = readNextLine.split(",");

                    //Creating a file with a database name
                    File dFile = new File(data[0] + ".db");
                    if (dFile.exists() == true) {
                        if (tableExist(data[1]).equalsIgnoreCase(data[1])) {
                            if (keyColumnExist(data[2], data[1]) == true) {
                                if (getKeyColumnValue(data[1], data[3], data[2]).equalsIgnoreCase(data[3])) {
                                    if (columnExist(data[4], data[1]) == true) {
                                        if (columnValueMatch(data[4], data[1], data[5]).equalsIgnoreCase(data[5])) {
                                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5] +" OK\n";
                                           // continue;
                                        }else {
                                            try {
                                                assertThat(data[5]+" does not match1",data[5] ,is(equalTo(columnValueMatch(data[4], data[1], data[5]))));

                                            } catch (AssertionError e) {
                                                dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not match\n";
                                                //dataLine += data[5]+" does not match" + "\n";
                                                continue;
                                            }
                                        }
                                    }else{
                                        try {
                                            assertThat(data[4]+" does not exist",true ,is(columnExist(data[4], data[1])));

                                        } catch (AssertionError e) {
                                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not exist" + "\n";
                                            continue;
                                        }
                                    }
                                }else{
                                    try {
                                        assertThat(data[3]+" does not match",data[3] ,equalTo(getKeyColumnValue(data[1], data[3], data[2])));
                                    } catch (AssertionError e) {
                                        dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not match" + "\n";
                                        continue;
                                    }
                                }
                            }else{
                                try {
                                    assertThat(data[2]+" does not exist", true, is(columnExist(data[4],data[1])));
                                } catch (AssertionError e) {
                                    dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+" does not exist" + "\n";
                                    continue;
                                }
                            }
                        } else {
                            try {
                                assertThat("Invalid Table", data[1], is(equalTo(tableExist(data[1]))));
                            } catch (AssertionError e) {
                                dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+ " Invalid Table" + "\n";
                                // System.out.println(e.getMessage());
                                continue;
                            }
                        }

                    } else {
                        try {
                            assertThat("Invalid Database", true, is(dFile.exists()));
                        } catch (AssertionError e) {
                            dataLine = dataLine + data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5]+ " Invalid Database" + "\n";
                            continue;
                        }
                    }


            } catch (ArrayIndexOutOfBoundsException ex) {
                if (ex.getMessage().equals("0")) {
                    System.out.println("Error: Database can not be empty at index " + ex.getMessage());
                } else if (ex.getMessage().equals("1")) {
                    System.out.println("Error: Table can not be empty at index " + ex.getMessage());
                } else if (ex.getMessage().equals("2")) {
                    System.out.println("Error: Key Column can not be empty at index " + ex.getMessage());
                } else if (ex.getMessage().equals("3")) {
                    System.out.println("Error: Key Value can not be empty at index " + ex.getMessage());
                } else if (ex.getMessage().equals("4")) {
                    System.out.println("Error: Column can not be empty at index " + ex.getMessage());
                } else if (ex.getMessage().equals("5")) {
                    System.out.println("Error: Column Value can not be empty at index " + ex.getMessage());
                }
                continue;
            }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }


    //Checking if the table exist
    public static String tableExist(String tableName) {
        String sql="SELECT name FROM sqlite_master WHERE type='table' AND name='"+tableName+"'";
        PreparedStatement prst;
        String name="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            name=rs.getString("name");
        } catch (SQLException e) {
            System.out.println("Sql Error, "+e.getMessage());
        }
        return name;
    }

    //Check if table column exist
    public static boolean keyColumnExist(String name,String tableName){
        boolean isExist=false;
        String sql="select count("+name+") 'column' FROM '"+tableName+"'";
        PreparedStatement prst=null;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("column"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            System.out.println(name+" does not exist");
        }
        return isExist;
    }

    public static boolean columnExist(String name,String tableName){
        boolean isExist=false;
        String sql="select count("+name+") 'column' FROM '"+tableName+"'";
        PreparedStatement prst=null;
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            if(Integer.valueOf(rs.getString("column"))>0){
                isExist=true;
            }
        } catch (SQLException e) {
            System.out.println(name+" does not exist");
        }
        return isExist;
    }

    public static String getKeyColumnValue(String tableName,String keyColumnValue,String keyColumn){
        String sql="select "+keyColumnValue+" 'Value' from "+tableName+" where "+keyColumn+" = '"+keyColumnValue+"'";
        PreparedStatement prst=null;
        String value="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            value=rs.getString("Value");
        } catch (SQLException e) {
            System.out.println(keyColumnValue+ " Does not match");
        }
        return value;
    }
    public static String columnValueMatch(String columnName,String tableName,String columnValue){
        String sql="select "+columnName+" 'value' from "+tableName+" where "+columnName+" = '"+columnValue+"'";
        PreparedStatement prst;
        String value="";
        try {
            prst=conn.prepareStatement(sql);
            rs=prst.executeQuery();
            value=rs.getString("value");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return value;
    }
}
