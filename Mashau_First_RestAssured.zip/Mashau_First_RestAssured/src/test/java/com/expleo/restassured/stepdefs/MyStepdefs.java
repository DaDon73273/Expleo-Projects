package com.expleo.restassured.stepdefs;

import com.expleo.restassured.steps.Posts;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class MyStepdefs {

    @Steps
    Posts posts;

    private String id="6";
    private String expectedName="Danica";
    @Given("^I have a valid author ID$")
    public void iHaveAValidAuthorID() {
        //TODO Still need to decide what to code
    }

    @When("^I submit the valid author id$")
    public void iSubmitTheValidAuthorId() {
        posts.submitValidAuthorId(id);
    }

    @Then("^I should see the author of the post$")
    public void iShouldSeeTheAuthorOfThePost() {
        posts.retrieveTheAuthorName(posts.i_should_Receive_CountryName_As(expectedName));
    }
}
