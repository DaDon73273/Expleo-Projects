package com.expleo.restassured.steps;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import net.thucydides.core.annotations.Step;



import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class Posts {

    RequestSpecification requestSpec;
    ResponseSpecification responseSpec;
    private String id;

    @Step
    public void submitValidAuthorId(String authorId){
            id=authorId;
            getAuthorId();
    }

    @Step("Message: {0}")
    public void retrieveTheAuthorName(String message){ }


    public void getAuthorId(){
        requestSpec=new RequestSpecBuilder()
                .setBaseUri("http://10.9.10.139:3000")
                .setBasePath("/posts")
                //.addPathParam("id",id)
                .build();
    }




    public String i_should_Receive_CountryName_As(String expectedAuthorName){
        try{
            responseSpec=new ResponseSpecBuilder()
                    .expectBody("author",equalTo(expectedAuthorName))
                    .expectStatusCode(200)
                    .build();
            Response response=given(requestSpec,responseSpec).get(id);
            response.then().log().all();
        }catch (AssertionError e){

            expectedAuthorName+=" does not match actual Author Name";
        }

        return expectedAuthorName;
    }

}
